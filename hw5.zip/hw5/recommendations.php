<?php

	/* KIND OF A WEIRD FORMATTING TO DO THIS, BUT I WANTED
	TO MESS AROUND WITH ORDERED LISTS. MAY NEED CHANGING IN THE FUTURE. - Jacob*/


	/* This will output 10 elements from an array that will eventually be generated
	from our recommendation calculations. I just filled the array with dummy strings
	in the initial for loop below. */

	include( 'header.php' );

	check_user( true );

	include( 'db_functions.php' );

?>


<!-- IGNORE THIS SECTION ~Jake
<?php

	$connection = mysql_connect('127.0.0.1', 'jakejeffreys', 'easter-egg-pw123');
	mysql_select_db('tinder_for_fruits');

	$query = "SELECT * FROM user_preferences"; //You don't need a ; like you do in SQL
	$result = mysql_query($query);

	echo "<table>"; // start a table tag in the HTML

	while($row = mysql_fetch_array($result)){   //Creates a loop to loop through results
		echo "<tr><td>" . $row['name'] . "</td><td>" . $row['age'] . "</td></tr>";  //$row['index'] the index here is a field name
	}

	echo "</table>"; //Close the table in HTML

	mysql_close(); //Make sure to close out the database connection

?> -->




<!--
<div class="recs centered ">

	<h4> Here are your top recommened fruits or vegetables! </h4>

	<?php

		$recs = array(); // create array for recommendations

		array_pad($recs, 10, 0); // Pad array to 10 values used for testing

		for($x = 0; $x < 10; $x++){ // Loop 10 times

			$recs[$x] = "Bananas"; // Assign each element to a test string
		}

		echo "<ul>"; // "unordered list" for list like output (not really necessary)
			for($x = 0; $x < 10; $x++){ // Loop 10 times

				echo "<li> ".$recs[$x]."</li>"."<br>"; // output each element as list
			}

		echo "</ul>"
	?>

</div>
-->

<div class="mdl-grid">

    <div class="title top-40 centered mdl-cell mdl-cell--8-col mdl-cell--8-col-tablet">
        Top 10 fruits for you
    </div>

    <div class="recommendations top-40 centered mdl-cell mdl-cell--8-col mdl-cell--8-col-tablet">

		<table class="mdl-data-table mdl-js-data-table mdl-shadow--2dp centered" style="width:100%">
		  <thead>
		    <tr>
		      <th>Rank</th>
		      <th>Image</th>
		      <th>Name</th>
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
		      <td>1</td>
		      <td><img src="img/watermelon.jpg" style="width:100px;height:70px;"> <br><br> </td>
		      <td>Watermelon</td>
		    </tr>
		    <tr>
		      <td>2</td>
		      <td><img src="img/banana.jpg" style="width:100px;height:70px;"> <br><br> </td>
		      <td>Banana</td>

		    </tr>
		    <tr>
		  	  <td>3</td>
		      <td><img src="img/apple.jpg" style="width:100px;height:70px;"> <br><br> </td>
		      <td>Apple</td>

		    </tr>
		  </tbody>
		</table>

	</div>
</div>





<?php include( 'footer.php' ); ?>
