<?php

include("check_user.php");
include("db_functions.php");
include("vector_functions.php");

$recs = array();

// Turn off re-direct and exit if there is no user logged in
$user_id = check_user( false, true );

if ( !$user_id )
{
    http_response_code( 400 );
    exit();
}

$query      = "SELECT id from users where email = '$user_id'";
$result     = mysql_select( $query ); // don't need to escape since we get it from the session
$rec_ids    = calculate_recs( $result->fetch_assoc()[ 'id' ] );

$recs = array();

foreach ( $rec_ids as $id )
{
    $query      = "SELECT name, image from items where id = '$id'";
    $res        = mysql_select( $query );
    $res        = $res->fetch_assoc();

    $recs     []= [ 'id' => $id, 'name' => $res[ 'name' ], 'image' => $res[ 'image' ] ];
}

echo json_encode($recs);


?>
