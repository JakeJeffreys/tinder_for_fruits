Note: Data entry page is play.php

Authors:
Bret Lorimore		lorimorb
Jacob Fenger		fengerj
Jake Jeffreys		jeffreyn
Chris Tucker		tuckerch
