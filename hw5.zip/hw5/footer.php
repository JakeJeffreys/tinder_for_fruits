        </div>
    </main>
</div>
<script src="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
    $( '#logout' ).click(function() {
        location.replace( 'logout<?php echo $FILE_EXT; ?>' )
    });
</script>
